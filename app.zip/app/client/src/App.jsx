import './App.css'
import {Route, Routes} from "react-router-dom";
import Add from './pages/Add';
import HomePage from './pages/HomePage';



function App() {
    const myStyle={
        backgroundImage: 
 "url('')",
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        height:'100vh',
    };

  return (

    <div style={myStyle}>
    <Routes>
        <Route index element={<HomePage />} />
        <Route path="/add" element={<Add />} />
      
    </Routes>
    </div>
  )
}

export default App
