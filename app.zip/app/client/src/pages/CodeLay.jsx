export default function CodeLay() {
    function GenerateCodes(){

        var nr = localStorage.getItem('codes');
      
        const deleteCode = (useText) => {

            for (var i = 1; i <= nr; i++) {
                if(localStorage.getItem(i) == useText)
                     localStorage.removeItem(i);
            }
           
            GenerateCodes();
            window.location.reload();

        };

    var divs = [];
      for (var i = 1; i <= nr; i++) {
        var useText = localStorage.getItem(i);
        var codeG = Math.floor(Math.random() * (999999 - 0 + 1)) + 0
        if(useText){
            divs.push(
            <div key={i}>
                <div className="flex align-middle justify-center mt-8">
                <div className="border pl-10 pr-40 py-5 border-gray-300 rounded-full shadow-md">
                    <h3 className="text-sky-600 text-2xl">{codeG}</h3>
                    <h3 className="rounded">{useText}</h3>
                </div>
                <div>
                    <button onClick={() => deleteCode(useText)} className="border rounded-full -ml-12 px-2 py-1 text-white text-m bg-primary">Delete</button>
                </div>
                </div>
            </div>
            );
      }}
  
      return divs;
    }
  
    return (
      <div>
        <GenerateCodes />
      </div>
    );
  }
  