import { Link } from "react-router-dom";
import { useState } from "react";


export default function Add() {
  const [userText, setText] = useState([]);
  
  async function addCode(ev) {
    ev.preventDefault();
    var i = localStorage.getItem('codes');
    i++;
    localStorage.setItem(i, userText);
    localStorage.setItem('codes', i);
  }

  return (
    <div>
      <div>
        <header className="p-10 mt-20">
          <div className="flex align-middle justify-center">
            <div className="bg-primary text-white flex border border-gray-300 rounded-full py-4 px-14 gap-4 shadow-md">
              <h1 class>New MFA</h1>
            </div>
          </div>

          <div className="flex align-middle justify-center ml-30 mr-30 mt-6">
            <input
              type="text"
              className=""
              placeholder="Text or Email"
              value={userText}
              onChange={(ev) => setText(ev.target.value)}
            />
          </div>

            <div className="flex align-middle justify-center mt-5 ml-40">
              <button
                className="border rounded-full px-3 py-1 text-white text-2xl bg-primary"
                onClick={addCode}
              >
                +
              </button>
            </div>
        </header>
      </div>
    </div>
  );
}
