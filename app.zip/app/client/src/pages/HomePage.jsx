
import { Link } from "react-router-dom";
import CodeLay from "./CodeLay";

export default function HomePage(){

    return (
        <div>
          <header className="p-10">
            <div className="flex align-middle justify-center">
              <div className='  bg-primary text-white  flex border  border-gray-300 rounded-full py-4 px-14 gap-4 shadow-md'>
                <h1 class>Authentificator</h1>
              </div>
            </div>
            <CodeLay />
            <Link to="/add">
                <div className="flex align-middle justify-center mt-5 ml-40">
                    <button className="border rounded-full  px-3 py-1 text-white text-2xl bg-primary  ">+</button>
                </div>
                </Link>
          </header>
        </div>
    );
}